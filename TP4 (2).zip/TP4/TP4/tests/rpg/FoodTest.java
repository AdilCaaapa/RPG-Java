package rpg;

import static org.junit.jupiter.api.Assertions.*;

class FoodTest {

}